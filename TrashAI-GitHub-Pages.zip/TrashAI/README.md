# TrashAI – Website phân loại rác bằng AI

Website tĩnh gồm 4 trang riêng:
- `index.html` – Trang chủ và giao diện phân loại.
- `history.html` – Lịch sử phân loại.
- `guide.html` – Hướng dẫn sử dụng.
- `about.html` – Giới thiệu dự án và công nghệ.

## 1. Đưa lên GitHub Pages
1. Giải nén thư mục `TrashAI`.
2. Tải toàn bộ nội dung bên trong thư mục lên repository GitHub của bạn.
3. Đảm bảo `index.html` nằm ở thư mục gốc (root), cùng cấp với `history.html`, `guide.html`, `about.html`.
4. Vào **Settings → Pages**.
5. Chọn **Deploy from a branch** → Branch `main` → Folder `/(root)` → Save.
6. Đợi GitHub Pages triển khai, sau đó mở địa chỉ website GitHub Pages của repository.

## 2. Chức năng hiện có
- Điều hướng qua 4 trang HTML độc lập.
- Chọn ảnh từ thiết bị, kéo thả ảnh, xem trước và xóa ảnh.
- Mở camera (trên HTTPS và khi người dùng cấp quyền), chụp ảnh.
- Hiển thị kết quả nhận diện và hướng xử lý khi mô hình được tích hợp.
- Lưu lịch sử trên trình duyệt bằng `localStorage`; lịch sử chỉ nằm trên thiết bị/trình duyệt hiện tại.
- Tìm kiếm và xóa lịch sử.

## 3. Kết nối mô hình AI thật
Giao diện sử dụng TensorFlow.js và chờ mô hình tại `model/model.json`.
Đọc kỹ `model/README.txt` để biết định dạng đầu vào/đầu ra cần thiết.

Định hướng mô hình: MobileNetV3 đã được huấn luyện/tinh chỉnh với dữ liệu rác. Website yêu cầu mô hình TensorFlow.js LayersModel:
- Input: `[1, 224, 224, 3]`, RGB, pixel chuẩn hóa `[0,1]`.
- Output: 6 lớp theo thứ tự: nhựa, giấy, kim loại, hữu cơ, thủy tinh, khác.

**Quan trọng:** Repo không kèm mô hình đã huấn luyện. Vì vậy, nếu chưa thêm mô hình, website vẫn có giao diện, tải ảnh và camera hoạt động, nhưng nút phân loại sẽ thông báo chưa tích hợp AI thay vì bịa kết quả. Độ tin cậy chỉ có ý nghĩa khi mô hình thật được tích hợp và đánh giá.

## 4. Lưu ý
- Dùng HTTPS để trình duyệt cho phép truy cập camera. GitHub Pages mặc định hỗ trợ HTTPS.
- Lịch sử được lưu cục bộ trong trình duyệt, không đồng bộ giữa các thiết bị.
- Không tải dữ liệu ảnh lên máy chủ; xử lý mô hình (sau khi tích hợp) diễn ra trên trình duyệt.
