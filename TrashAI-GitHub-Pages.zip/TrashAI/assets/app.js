(() => {
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "trashai_history_v1";
  const CLASS_INFO = {
    "Rác nhựa": {icon:"♻", steps:["Làm sạch, loại bỏ thức ăn hoặc chất lỏng còn lại.","Làm dẹt chai/hộp nếu có thể để tiết kiệm diện tích.","Đưa đến điểm thu gom hoặc thùng dành cho rác tái chế theo quy định địa phương."]},
    "Rác giấy": {icon:"📄", steps:["Giữ giấy khô, sạch; tách khỏi giấy dính dầu mỡ hoặc hóa chất.","Gấp gọn hoặc bó lại để thuận tiện thu gom.","Đưa vào điểm thu gom giấy tái chế."]},
    "Rác kim loại": {icon:"🥫", steps:["Làm sạch lon và vật chứa nếu an toàn.","Không dùng tay trần xử lý vật sắc cạnh; bọc kín cạnh sắc.","Đưa đến điểm thu gom kim loại tái chế."]},
    "Rác hữu cơ": {icon:"🍂", steps:["Tách riêng thức ăn thừa, vỏ rau củ và lá cây.","Có thể tận dụng phần phù hợp để ủ phân hữu cơ.","Đựng riêng, đậy kín và chuyển giao theo hướng dẫn thu gom địa phương."]},
    "Rác thủy tinh": {icon:"🍾", steps:["Không đập vỡ chai lọ để phân loại.","Nếu thủy tinh vỡ, dùng dụng cụ bảo hộ và bọc kín an toàn.","Đưa đến điểm thu gom thủy tinh phù hợp."]},
    "Rác khác": {icon:"🗑", steps:["Tách riêng khỏi nhóm có thể tái chế hoặc hữu cơ.","Kiểm tra xem vật đó có thuộc nhóm rác nguy hại/đặc thù không.","Làm theo hướng dẫn thu gom rác tại địa phương."]}
  };
  const LABELS = ["Rác nhựa","Rác giấy","Rác kim loại","Rác hữu cơ","Rác thủy tinh","Rác khác"];
  let selectedFile = null, cameraStream = null, latestResult = null, model = null;

  function readHistory(){ try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");}catch(e){return [];} }
  function writeHistory(items){ localStorage.setItem(STORAGE_KEY,JSON.stringify(items)); }
  function formatDate(value){ return new Date(value).toLocaleString("vi-VN",{dateStyle:"medium",timeStyle:"short"}); }
  function showError(message){ const box=$("errorMessage"); if(box){box.textContent=message;box.classList.remove("hidden");} }
  function clearError(){ const box=$("errorMessage"); if(box){box.textContent="";box.classList.add("hidden");} }

  async function loadModel(){
    const status=$("modelStatus"), button=$("classifyButton");
    if(!status || !button) return;
    try{
      if(!window.tf) throw new Error("Không tải được TensorFlow.js. Hãy kiểm tra kết nối Internet.");
      await tf.ready();
      model=await tf.loadLayersModel("model/model.json");
      status.textContent="✓ Mô hình AI đã sẵn sàng.";
      status.style.color="#168a3b";
      button.disabled=!selectedFile;
    }catch(err){
      status.textContent="Chưa tìm thấy mô hình AI đã huấn luyện.";
      status.style.color="#a36b16";
      button.disabled=!selectedFile;
    }
  }

  function stopCamera(){
    if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null;}
    const video=$("cameraVideo"); if(video) video.srcObject=null;
  }
  function setPreview(file){
    if(!file || !file.type.startsWith("image/")){showError("Vui lòng chọn tệp hình ảnh hợp lệ.");return;}
    selectedFile=file; clearError(); stopCamera();
    const reader=new FileReader();
    reader.onload=()=>{$("previewImage").src=reader.result;$("emptyState").classList.add("hidden");$("cameraWrap").classList.add("hidden");$("previewWrap").classList.remove("hidden");$("classifyButton").disabled=false;};
    reader.readAsDataURL(file);
  }
  function resetImage(){
    selectedFile=null; latestResult=null;
    $("previewWrap")?.classList.add("hidden");$("emptyState")?.classList.remove("hidden");
    $("classifyButton") && ($("classifyButton").disabled=true);
    $("resultContent")?.classList.add("hidden");$("resultEmpty")?.classList.remove("hidden");
    $("imageInput") && ($("imageInput").value="");clearError();
  }
  function activateTabs(){
    document.querySelectorAll(".tab-button").forEach(btn=>btn.addEventListener("click",async()=>{
      document.querySelectorAll(".tab-button").forEach(b=>b.classList.toggle("active",b===btn));
      if(btn.dataset.mode==="upload"){stopCamera();$("cameraWrap").classList.add("hidden");if(selectedFile)$("previewWrap").classList.remove("hidden");else $("emptyState").classList.remove("hidden");}
      else{
        $("emptyState").classList.add("hidden");$("previewWrap").classList.add("hidden");$("cameraWrap").classList.remove("hidden");
        try{cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});$("cameraVideo").srcObject=cameraStream;}
        catch(e){showError("Không thể mở camera. Hãy cấp quyền camera và truy cập website bằng HTTPS, hoặc chọn Tải ảnh.");$("cameraWrap").classList.add("hidden");$("emptyState").classList.remove("hidden");}
      }
    }));
  }
  async function capturePhoto(){
    const video=$("cameraVideo"); if(!video || !video.videoWidth){showError("Camera chưa sẵn sàng. Vui lòng thử lại.");return;}
    const canvas=document.createElement("canvas");canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext("2d").drawImage(video,0,0);
    canvas.toBlob(blob=>{if(blob)setPreview(new File([blob],"trashai-camera.jpg",{type:"image/jpeg"}));},"image/jpeg",.92);
  }
  async function classify(){
    if(!selectedFile)return;
    clearError();
    if(!model){showError("Mô hình AI chưa được tích hợp. Hãy thêm mô hình đã huấn luyện vào thư mục model/model.json theo hướng dẫn README.md. Website chưa tạo kết quả nhận diện giả.");return;}
    $("resultEmpty").classList.add("hidden");$("resultContent").classList.add("hidden");$("resultLoading").classList.remove("hidden");
    try{
      const image=await createImageBitmap(selectedFile);
      const prediction=tf.tidy(()=>{
        const tensor=tf.browser.fromPixels(image).resizeBilinear([224,224]).toFloat().div(255).expandDims(0);
        return model.predict(tensor);
      });
      const values=Array.from(await prediction.data());prediction.dispose();image.close();
      if(values.length!==LABELS.length) throw new Error("Mô hình cần trả về đúng 6 giá trị theo thứ tự lớp được ghi trong README.");
      const bestIndex=values.indexOf(Math.max(...values));
      const name=LABELS[bestIndex], confidence=Math.max(0,Math.min(1,values[bestIndex]))*100;
      latestResult={id:Date.now().toString(),name,confidence:Number(confidence.toFixed(1)),createdAt:new Date().toISOString(),imageData:await fileToDataURL(selectedFile)};
      renderResult(latestResult);
      const items=readHistory();items.unshift(latestResult);writeHistory(items.slice(0,100));
      $("saveResult").textContent="✓ Đã lưu lịch sử";
    }catch(err){showError("Không thể phân tích ảnh: "+err.message);$("resultEmpty").classList.remove("hidden");}
    finally{$("resultLoading").classList.add("hidden");}
  }
  function fileToDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
  function renderResult(item){
    const info=CLASS_INFO[item.name]||CLASS_INFO["Rác khác"];
    $("resultIcon").textContent=info.icon;$("resultName").textContent=item.name;
    $("resultConfidence").textContent=item.confidence.toFixed(1)+"%";
    $("resultSteps").innerHTML=info.steps.map(s=>`<li>${escapeHTML(s)}</li>`).join("");
    $("resultTime").textContent=formatDate(item.createdAt);
    $("resultEmpty").classList.add("hidden");$("resultContent").classList.remove("hidden");
  }
  function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function initHome(){
    if(!$("imageInput"))return;
    $("chooseImage").addEventListener("click",()=>$("imageInput").click());
    $("imageInput").addEventListener("change",e=>{if(e.target.files[0])setPreview(e.target.files[0]);});
    $("removeImage").addEventListener("click",resetImage);
    $("classifyButton").addEventListener("click",classify);
    $("captureImage").addEventListener("click",capturePhoto);
    $("dropZone").addEventListener("dragover",e=>{e.preventDefault();$("dropZone").classList.add("dragging");});
    $("dropZone").addEventListener("dragleave",()=>$("dropZone").classList.remove("dragging"));
    $("dropZone").addEventListener("drop",e=>{e.preventDefault();$("dropZone").classList.remove("dragging");if(e.dataTransfer.files[0])setPreview(e.dataTransfer.files[0]);});
    $("saveResult").addEventListener("click",()=>{if(latestResult){const items=readHistory();if(!items.some(x=>x.id===latestResult.id)){items.unshift(latestResult);writeHistory(items);} $("saveResult").textContent="✓ Đã lưu lịch sử";}});
    activateTabs();loadModel();
    window.addEventListener("beforeunload",stopCamera);
  }
  function initHistory(){
    const list=$("historyList"),empty=$("historyEmpty");if(!list)return;
    function draw(query=""){
      const items=readHistory().filter(x=>x.name.toLowerCase().includes(query.toLowerCase()));
      list.innerHTML=items.map(item=>`<article class="history-item"><img src="${item.imageData}" alt="Ảnh đã phân loại"><div class="history-info"><b>${escapeHTML(item.name)}</b><small>${formatDate(item.createdAt)}</small></div><span class="history-confidence">${Number(item.confidence).toFixed(1)}%</span><button class="history-delete" data-id="${item.id}" aria-label="Xóa mục này">×</button></article>`).join("");
      empty.classList.toggle("hidden",items.length!==0);
      list.querySelectorAll(".history-delete").forEach(btn=>btn.addEventListener("click",()=>{writeHistory(readHistory().filter(x=>x.id!==btn.dataset.id));draw($("historySearch").value);}));
    }
    $("historySearch").addEventListener("input",e=>draw(e.target.value));
    $("clearHistory").addEventListener("click",()=>{if(confirm("Bạn có chắc muốn xóa toàn bộ lịch sử phân loại trên thiết bị này?")){writeHistory([]);draw();}});
    draw();
  }
  document.addEventListener("DOMContentLoaded",()=>{initHome();initHistory();});
})();