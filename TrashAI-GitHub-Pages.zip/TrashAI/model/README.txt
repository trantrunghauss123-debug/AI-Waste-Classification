THƯ MỤC MÔ HÌNH AI

Để bật nhận diện thực tế, đặt mô hình TensorFlow.js đã huấn luyện vào thư mục này:
- model.json
- Các tệp trọng số được model.json tham chiếu (ví dụ group1-shard1of1.bin)

Yêu cầu tương thích với assets/app.js:
1. Mô hình phải là TensorFlow.js LayersModel, tải được bằng tf.loadLayersModel("model/model.json").
2. Đầu vào: ảnh RGB kích thước 224 x 224, giá trị pixel chuẩn hóa về [0, 1].
3. Đầu ra: một vector gồm đúng 6 xác suất/điểm số theo đúng thứ tự:
   0: Rác nhựa
   1: Rác giấy
   2: Rác kim loại
   3: Rác hữu cơ
   4: Rác thủy tinh
   5: Rác khác

Lưu ý: Đây là hợp đồng đầu vào/đầu ra để website kết nối mô hình. Mô hình MobileNetV3 cần được huấn luyện/tinh chỉnh và xuất sang định dạng TensorFlow.js tương thích. Không đổi tên file model.json nếu chưa sửa đường dẫn trong assets/app.js.
